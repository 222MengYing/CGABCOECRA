
clc
clear 
close all

%% Initialization
InitEng = 0.5; 
NetSize =40; 
NoOfNode = 60;
NoOfRound = 3000;
cluster_head_percentage = 0.1;
xm = NetSize; 
ym = NetSize; 
for i=1:1:NoOfNode 
    S(i).xd=rand(1,1)*xm;
    XR(i)=S(i).xd;
    S(i).yd=rand(1,1)*ym;
    YR(i)=S(i).yd;
    S(i).G=0; 
    S(i).type='N';
    S(i).E=InitEng; 
end


[STATISTICS] = leach(InitEng,NetSize,NoOfNode,NoOfRound,cluster_head_percentage,S);
[STATISTICS2] = I-SEP(InitEng,NetSize,NoOfNode,NoOfRound,cluster_head_percentage,S);
[STATISTICS3] = OptGACHE(InitEng,NetSize,NoOfNode,NoOfRound,cluster_head_percentage,S);
[STATISTICS4] = myClusterApproachABC(InitEng,NetSize,NoOfNode,NoOfRound,cluster_head_percentage,S);

%% 1
Residual_first_dead_energy=STATISTICS.first_dead_energy(find(STATISTICS.first_dead_energy~=0));
Residual_first_dead_energy2=STATISTICS2.first_dead_energy(find(STATISTICS2.first_dead_energy~=0));
Residual_first_dead_energy3=STATISTICS3.first_dead_energy(find(STATISTICS3.first_dead_energy~=0));
Residual_first_dead_energy4=STATISTICS4.first_dead_energy(find(STATISTICS4.first_dead_energy~=0));
%% 10%
Residual_teenth_dead_energy=STATISTICS.teenth_dead_energy(find(STATISTICS.teenth_dead_energy~=0));
Residual_teenth_dead_energy2=STATISTICS2.teenth_dead_energy(find(STATISTICS2.teenth_dead_energy~=0));
Residual_teenth_dead_energy3=STATISTICS3.teenth_dead_energy(find(STATISTICS3.teenth_dead_energy~=0));
Residual_teenth_dead_energy4=STATISTICS4.teenth_dead_energy(find(STATISTICS4.teenth_dead_energy~=0));
%% 25%
Residual_quarter_dead_energy=STATISTICS.quarter_dead_energy(find(STATISTICS.quarter_dead_energy~=0));
Residual_quarter_dead_energy2=STATISTICS2.quarter_dead_energy(find(STATISTICS2.quarter_dead_energy~=0));
Residual_quarter_dead_energy3=STATISTICS3.quarter_dead_energy(find(STATISTICS3.quarter_dead_energy~=0));
Residual_quarter_dead_energy4=STATISTICS4.quarter_dead_energy(find(STATISTICS4.quarter_dead_energy~=0));
%% 50%
Residual_half_dead_energy=STATISTICS.half_dead_energy(find(STATISTICS.half_dead_energy~=0));
Residual_half_dead_energy2=STATISTICS2.half_dead_energy(find(STATISTICS2.half_dead_energy~=0));
Residual_half_dead_energy3=STATISTICS3.half_dead_energy(find(STATISTICS3.half_dead_energy~=0));
Residual_half_dead_energy4=STATISTICS4.half_dead_energy(find(STATISTICS4.half_dead_energy~=0));

%% 1.NETWORK LIFETIME
figure
len_01 = STATISTICS.all_dead % 
plot(1:len_01,STATISTICS.ALLIVE(1:len_01),'-om'); 
hold on
len_02 = STATISTICS2.all_dead
plot(1:len_02,STATISTICS2.ALLIVE(1:len_02),'-*c'); 
hold on
len_03 = STATISTICS3.all_dead
plot(1:len_03,STATISTICS3.ALLIVE(1:len_03),'-sg'); 
hold on
len_04 = STATISTICS4.all_dead
plot(1:len_04,STATISTICS4.ALLIVE(1:len_04),'-or'); 
hold on

legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');
xlabel('Rounds');
ylabel('The number of living nodes');


% Network lifetime with different node death times (rounds).
figure
y_01=[STATISTICS.first_dead,STATISTICS2.first_dead,STATISTICS3.first_dead,STATISTICS4.first_dead;
    STATISTICS.teenth_dead,STATISTICS2.teenth_dead,STATISTICS3.teenth_dead,STATISTICS4.teenth_dead;
    STATISTICS.quarter_dead,STATISTICS2.quarter_dead,STATISTICS3.quarter_dead,STATISTICS4.quarter_dead;
    STATISTICS.half_dead,STATISTICS2.half_dead,STATISTICS3.half_dead,STATISTICS4.half_dead;
    STATISTICS.all_dead,STATISTICS2.all_dead,STATISTICS3.all_dead,STATISTICS4.all_dead;]
b=bar(y_01);
grid on;
ch = get(b,'children');
set(gca,'XTickLabel',{'One node dies','10% nodes die','25% nodes die','50% nodes die','All nodes die'})
set(gca,'YLim',[0 3000]);%y
xlabel('Node death time');
ylabel('Rounds');
legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');

% % % Total residual energy
figure
plot(1:len_01, STATISTICS.TotalEnergy(1:len_01),'-m');
hold on;
plot(1:len_02, STATISTICS2.TotalEnergy(1:len_02),'-c');
hold on;
plot(1:len_03, STATISTICS3.TotalEnergy(1:len_03),'-g');
hold on;
plot(1:len_04, STATISTICS4.TotalEnergy(1:len_04),'-r');
legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');
ylabel('Total network energy (J)');
xlabel('Rounds');

% %% Average residual energy
figure
plot(1:len_01, STATISTICS.AvgEnergy(1:len_01),'-m');
hold on;
plot(1:len_02, STATISTICS2.AvgEnergy(1:len_02),'-c');
hold on;
plot(1:len_03, STATISTICS3.AvgEnergy(1:len_03),'-g');
hold on;
plot(1:len_04, STATISTICS4.AvgEnergy(1:len_04),'-r');
legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');
ylabel('Average residual energy (J)');
xlabel('Rounds');

% Residual energy distribution (1)
figure
plot(1:NoOfNode, STATISTICS.first_dead_energy,'-vm');
hold on;
plot(1:NoOfNode, STATISTICS2.first_dead_energy,'-*c');
hold on;
plot(1:NoOfNode, STATISTICS3.first_dead_energy,'-og');
hold on;
plot(1:NoOfNode, STATISTICS4.first_dead_energy,'-sk','MarkerFaceColor','k');
legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');
ylabel('Residual energy (J)');
xlabel('Number of nodes');

% Residual energy distribution (10%)
figure
plot(1:NoOfNode, STATISTICS.teenth_dead_energy,'-vm');
hold on;
plot(1:NoOfNode, STATISTICS2.teenth_dead_energy,'-*c');
hold on;
plot(1:NoOfNode, STATISTICS3.teenth_dead_energy,'-og');
hold on;
plot(1:NoOfNode, STATISTICS4.teenth_dead_energy,'-sk','MarkerFaceColor','k');
legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');
ylabel('Residual energy (J)');
xlabel('Number of nodes');

% Residual energy distribution (25%)
figure
plot(1:NoOfNode, STATISTICS.quarter_dead_energy,'-vm');
hold on;
plot(1:NoOfNode, STATISTICS2.quarter_dead_energy,'-*c');
hold on;
plot(1:NoOfNode, STATISTICS3.quarter_dead_energy,'-og');
hold on;
plot(1:NoOfNode, STATISTICS4.quarter_dead_energy,'-sk','MarkerFaceColor','k');
legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');
ylabel('Residual energy (J)');
xlabel('Number of nodes');

% Residual energy distribution (50%)
figure
plot(1:NoOfNode, STATISTICS.half_dead_energy,'-vm');
hold on;
plot(1:NoOfNode, STATISTICS2.half_dead_energy,'-*c');
hold on;
plot(1:NoOfNode, STATISTICS3.half_dead_energy,'-og');
hold on;
plot(1:NoOfNode, STATISTICS4.half_dead_energy,'-sk','MarkerFaceColor','k');
legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');
ylabel('Residual energy (J)');
xlabel('Number of nodes');


%% PACKETS_TO_BS
figure
plot(1:(NoOfRound+1), STATISTICS.PACKETS_TO_BS,'-om');
hold on
plot(1:(NoOfRound+1), STATISTICS2.PACKETS_TO_BS,'-*c');
hold on
plot(1:(NoOfRound+1), STATISTICS3.PACKETS_TO_BS,'-og');
hold on
plot(1:(NoOfRound+1), STATISTICS4.PACKETS_TO_BS,'-or');
legend('LEACH','I-SEP','OptGACHE','CGABCO-ECRA');
ylabel('The number of packets received by the BS');
xlabel('Rounds');
packet=[STATISTICS.PACKETS_TO_BS(NoOfRound+1),STATISTICS2.PACKETS_TO_BS(NoOfRound+1),STATISTICS3.PACKETS_TO_BS(NoOfRound+1),STATISTICS4.PACKETS_TO_BS(NoOfRound+1)]

%% 

figure
y_02 = [STATISTICS.total_delay, STATISTICS2.total_delay, STATISTICS3.total_delay, STATISTICS4.total_delay];
bar(y_02);
set(gca,'XTickLabel',{'LEACH','I-SEP','OptGACHE','CGABCO-ECRA'})
set(gca,'XTickLabelRotation',15)
set(gca,'YLim',[0,7]);%y
grid on;
ylabel('Average transmission delay (ms)');
% 


%% box plot
% first
figure
boxplot([Residual_first_dead_energy',Residual_first_dead_energy2',Residual_first_dead_energy3',Residual_first_dead_energy4'], 'Labels',{'LEACH','I-SEP','OptGACHE','CGABCO-ECRA'})
ylabel('Residual energy distribution of surviving nodes (J)');
%% 10%
figure
boxplot([Residual_teenth_dead_energy',Residual_teenth_dead_energy2',Residual_teenth_dead_energy3',Residual_teenth_dead_energy4'], 'Labels',{'LEACH','I-SEP','OptGACHE','CGABCO-ECRA'})
ylabel('Residual energy distribution of surviving nodes (J)');
%% 25%
figure
boxplot([Residual_quarter_dead_energy',Residual_quarter_dead_energy2',Residual_quarter_dead_energy3',Residual_quarter_dead_energy4'], 'Labels',{'LEACH','I-SEP','OptGACHE','CGABCO-ECRA'})
ylabel('Residual energy distribution of surviving nodes (J)');
%% 50%
figure
boxplot([Residual_half_dead_energy',Residual_half_dead_energy2',Residual_half_dead_energy3',Residual_half_dead_energy4'], 'Labels',{'LEACH','I-SEP','OptGACHE','CGABCO-ECRA'})
ylabel('Residual energy distribution of surviving nodes (J)');
 


