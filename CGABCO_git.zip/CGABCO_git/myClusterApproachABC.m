function [STATISTICS]=myClusterApproachABC(initEnergy,NetworkSize,NumberOfNodes,NumOfRound,cluster_head_percentage,S_input)

%% Initialization
xm=NetworkSize;
ym=NetworkSize;
sink.x=xm;
sink.y=0.5*ym;
n=NumberOfNodes; 
p=cluster_head_percentage; 
Eo = initEnergy;%Initial Energy of each node.
ETX=50*0.000000001; 
ERX=50*0.000000001; 
%Transmit Amplifier types
Efs=10*0.000000000001;
Emp=0.0013*0.000000000001;
%Data Aggregation Energy
EDA=5*0.000000001; 
rmax=NumOfRound;
do=sqrt(Efs/Emp);
S = S_input; 
S(n+1).xd=sink.x;
S(n+1).yd=sink.y;
flag_first_dead=0;
flag_teenth_dead = 0;
flag_quarter_dead = 0;
flag_half_dead=0;
flag_all_dead=0;
first_dead=0; 
teenth_dead = 0;
quarter_dead = 0;
half_dead=0; 
all_dead=0; 
allive=n; 
%counter for bit transmitted to Bases Station and to Cluster Heads
packets_TO_BS=0; 
sensor_num = NumberOfNodes; 
cluster_num = sensor_num*p; 
pop = zeros(pop_num,sensor_num); 
ratio_intra = 0.25; 
ratio_energy = 0.25; %
ratio_inter = 0.25; % 
ratio_delay=0.25;
for i = 1:pop_num
    collection = randperm(NumberOfNodes); 
    coun_cluster = 0;
    for j = 1:sensor_num 
        if S(collection(j)).E>0
            pop(i,collection(j)) = 1; 
            coun_cluster = coun_cluster+1; 
            if coun_cluster==cluster_num 
                break;
            end
        end
    end
   end
%% ABC==============================================
pop_num = 30; 
MAXGEN = 40; 
sensor_num = NumberOfNodes; 
cluster_num = sensor_num*p; 
pop = zeros(pop_num,sensor_num); 

for i = 1:pop_num
    collection = randperm(NumberOfNodes);  
    coun_cluster = 0; 
    for j = 1:sensor_num 
        if S(collection(j)).E>0
            pop(i,collection(j)) = 1; 
            coun_cluster = coun_cluster+1; 
            if coun_cluster==cluster_num 
                break;
            end
        end
    end
    
end
%%================================================================================

% packetLength = 4000;
% ctrPacketLength = 200;
total_delay = 0; %
% send_delay = 1.5; 
% receive_delay = send_delay;  

%% 
for r=0:1:rmax
    r
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    dead=0;

    for i=1:1:n
        if (S(i).E<=0)
            dead=dead+1;
            % 1%
            if (dead>=1)
                if(flag_first_dead==0)
                    first_dead = r;
                    flag_first_dead = 1;
                    for h = 1:n
                        first_dead_energy(h) = S(h).E;
                        if first_dead_energy(h) < 0
                            first_dead_energy(h) = 0;
                        end
                    end
                end
            end
            % 10%
            if (dead >= 0.1*n)
                if flag_teenth_dead ==0
                    teenth_dead = r;
                    flag_teenth_dead = 1;
                    for h=1:n
                        teenth_dead_energy(h) = S(h).E;
                        if teenth_dead_energy(h)<0
                            teenth_dead_energy(h) = 0;
                        end
                    end
                end
            end
            % 25%
            if (dead >= n*0.25)  
                if(flag_quarter_dead==0)  
                    quarter_dead=r;
                    flag_quarter_dead=1;
                    for h=1:n
                        quarter_dead_energy(h) = S(h).E;
                        if quarter_dead_energy(h)<0
                            quarter_dead_energy(h) = 0;
                        end
                    end
                end
            end
            % 50%
            if (dead >= n*0.5) 
                if(flag_half_dead==0) 
                    half_dead=r;
                    flag_half_dead=1;
                    for h=1:n
                        half_dead_energy(h) = S(h).E;
                        if half_dead_energy(h)<0
                            half_dead_energy(h) = 0;
                        end
                    end
                end
            end
            if(dead==n)
                if(flag_all_dead==0)
                    all_dead = r;
                    flag_all_dead = 1;
                end
            end
        end
        if S(i).E > 0 % 
            S(i).type='N';
        end
    end
    STATISTICS.DEAD(r+1) = dead; 
    dead2 = 0; 
    STATISTICS.ALLIVE(r+1) = allive-dead;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %Calculate the average energy of the whole network%
    Etotal = 0;
    for i=1:n
        if S(i).E>0
            Etotal = Etotal+S(i).E;
        end
    end
    
    if dead<n
        Eavg=Etotal/(n-dead);
    else
        Eavg = 0;
    end
    
    STATISTICS.TotalEnergy(r+1)=Etotal; %
    
    STATISTICS.AvgEnergy(r+1)=Eavg; %
    
    %%%%%%%%%%%%%%Improvement1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    countCHs=0;
    n-dead;
    %% ABC
    if (n-dead)> 10 %
        try             
            [Best_pos,Alpha_S,pop_output,CH_record] = ABC(pop_num,MAXGEN,pop,sensor_num,cluster_num,S,(n-dead),initEnergy,ratio_intra,ratio_energy,ratio_inter,0,1,n); 
        catch
            disp('当报错的时候还剩余的存活节点数量是')
            n-dead
        end
               pop = pop_output;  
        S = Alpha_S; 
       
        for i=1:1:n
            if(Best_pos(i) == 1) 
                distance = sqrt((S(i).xd-(S(n+1).xd))^2 + (S(i).yd-(S(n+1).yd))^2);
                if (distance>do)
                    S(i).E=S(i).E- ((ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance ));
                else
                    S(i).E=S(i).E- ((ETX+EDA)*(4000)  + Efs*4000*( distance * distance ));
                end
                packets_TO_BS = packets_TO_BS+1; 
            end
        end
        STATISTICS.COUNTCHS(r+1)=countCHs;
        for i=1:1:n
            if S(i).E>0 
                if  Best_pos(i) == 0  
                    if S(i).min_dis_cluster > 0 
                        min_dis = S(i).min_dis; 
                        if (min_dis>do)
                            S(i).E = S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis));
                        else
                            S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis));
                        end
                        S(CH_record(S(i).min_dis_cluster).id).E = S(CH_record(S(i).min_dis_cluster).id).E- ( (ERX + EDA)*200 );
                    end
                else 
                    min_dis = sqrt( (S(i).xd-S(n+1).xd)^2 + (S(i).yd-S(n+1).yd)^2 ); 
                    if (min_dis>do)
                        S(i).E=S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis));
                    end
                    if (min_dis<=do)
                        S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis));
                    end
                    packets_TO_BS=packets_TO_BS+1;
                end
            end
        end
    else 
        for i=1:1:n
            if S(i).E>0 
                min_dis = sqrt( (S(i).xd-S(n+1).xd)^2 + (S(i).yd-S(n+1).yd)^2 ); 
                if (min_dis>do)
                    S(i).E=S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis));
                else
                    S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis));
                end
                packets_TO_BS=packets_TO_BS+1;
            end
        end
    end
   
    STATISTICS.PACKETS_TO_BS(r+1)=packets_TO_BS;
    
end

STATISTICS.first_dead_energy = first_dead_energy; 
STATISTICS.teenth_dead_energy = teenth_dead_energy; 
STATISTICS.quarter_dead_energy = quarter_dead_energy; 
STATISTICS.half_dead_energy = half_dead_energy; 
STATISTICS.first_dead = first_dead; 
STATISTICS.teenth_dead = teenth_dead; 
STATISTICS.quarter_dead = quarter_dead; 
STATISTICS.half_dead = half_dead; 
STATISTICS.all_dead = all_dead;